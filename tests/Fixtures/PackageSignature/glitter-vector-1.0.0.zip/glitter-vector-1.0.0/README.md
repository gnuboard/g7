TEST ONLY vector package
